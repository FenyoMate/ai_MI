package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.lang.Math;
import java.util.Arrays;
import java.util.List;

public class Main {

    public static class point{
        int x,y;

        point(int X, int Y){
            x = X;
            y = Y;
        }
        public int getX(){
            return x;
        }
        public int getY(){
            return y;
        }
    }
    static class Graph
    {
        double[][] adjMatrix;
        int numOfvertices;
        List<point> points = new ArrayList<point>();

        Graph(double[][] mat, int v)
        {
            this.adjMatrix = mat;
            this.numOfvertices = v;
        }

        public Graph() {
            numOfvertices = 0;
            adjMatrix = new double[60][60];
        }

        void addEdge(int src, int dest, double edgeWeight)
        {
            adjMatrix[src][dest] = edgeWeight;
            adjMatrix[dest][src] = edgeWeight;
        }
        void setNumOfvertices(int i){
            numOfvertices = i;
        }
    }
    public static int getClosestVertex(double[] distance, boolean[] visited)
    {
        double min = Double.MAX_VALUE;
        int minIdx = -1;
        for(int i=0; i<distance.length; i++)
        {
            if(distance[i] < min)
                if(visited[i] == false)
                {
                    min = distance[i];
                    minIdx = i;
                }
        }
        return minIdx;
    }

    public static double[] dijkstrasShortestPath(Graph g, int src)
    {
        //final shortest distance array
        double[] distance = new double[g.numOfvertices];
        //array to tell whether shortest distance of vertex has been found
        boolean[] visited = new boolean[g.numOfvertices];

        //initializing the arrays
        for(int i=0; i<g.numOfvertices; i++)
        {
            distance[i] = Double.MAX_VALUE;//initial distance is infinite
            visited[i] = false;//shortest distance for any node has not been found yet
        }
        distance[src] = 0;

        for(int i=0; i<g.numOfvertices; i++)
        {
            int closestVertex = getClosestVertex(distance, visited);//get the closest node
            //if closest node is infinite distance away, it means that no other node can be reached. So
            if(closestVertex == Integer.MAX_VALUE)
                return distance;

            visited[closestVertex] = true;
            for(int j=0; j<g.numOfvertices; j++)
            {
                if(!visited[j])//shortest distance of the node j should not have been finalized
                {
                    if(g.adjMatrix[closestVertex][j] != 0)
                    {
                        double d = distance[closestVertex] + g.adjMatrix[closestVertex][j];
                        if(d < distance[j])//distance via closestVertex is less than the initial distance
                            distance[j] = d;
                    }
                }
            }
        }
        return distance;
    }


    public static void main(String[] args) {

        double[][] adjMat;
        Graph graph = new Graph();
        BufferedReader sysIn = new BufferedReader(new InputStreamReader(System.in));
        String currentLine = null;
        List<String> lines = new ArrayList<>();
        int phase = 0;
        try {
            currentLine = sysIn.readLine();
            while (!(currentLine == null) && phase != 4){
                lines.add(currentLine);
                if(currentLine.equals("")){
                    phase+=1;
                }
                currentLine = sysIn.readLine();

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        String[] splitter;
        int j = 0;
        phase = 0;
        graph.setNumOfvertices(Integer.parseInt(lines.get(1)));
        int tasks = Integer.parseInt(lines.get(0));
        int[] sources = new int[tasks];
        int[] destinations = new int[tasks];
        for (int i = 4; i < lines.size(); i++) {
            splitter = lines.get(i).split("\t");
            if(splitter[0].equals("")){
                j=0;
                phase+=1;
                break;
            }
            switch(phase){
                case 0:
                    sources[j] = Integer.parseInt(splitter[0]);
                    destinations[j] = Integer.parseInt(splitter[1]);
                    break;
                case 1:
                    int tempX = Integer.parseInt(splitter[0]);
                    int tempY = Integer.parseInt(splitter[1]);
                    graph.points.add(new point(tempX, tempY));
                    break;
                case 2:
                    tempX = Integer.parseInt(splitter[0]);
                    tempY = Integer.parseInt(splitter[1]);
                    int temp = graph.points.get(tempY).x-graph.points.get(tempX).x*graph.points.get(tempY).x-graph.points.get(tempX).x + graph.points.get(tempY).y-graph.points.get(tempX).y*graph.points.get(tempY).y-graph.points.get(tempX).y;
                    graph.addEdge(tempX, tempY, Math.sqrt(temp));

                    break;
            }
            j+=1;
        }
        for (int i = 0; i < sources.length; i++) {
            double[] dist = dijkstrasShortestPath(graph, sources[i]);
            System.out.print(Arrays.toString(dist));
        }





    }
}
